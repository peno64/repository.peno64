OpenSubtitles.com-dualsubtitles with dual subs KODI add-on
==========================================================

The possibility to use two subtitles at the same time was originally developed by moham96.
See https://github.com/moham96/service.subtitles.opensubtitles_by_opensubtitles

Search and download subtitles for movies and TV-Series from OpenSubtitles.com. Search in 75 languages, 8.000.000+ subtitles, daily updates.
Allow to display two subtitles at the same time

REST API implementation based on tomburke25 [python-opensubtitles-rest-api](https://github.com/tomburke25/python-opensubtitles-rest-api)

v2.0.4 (2026-07-14)
- Implemented changes from v1.0.9 till v1.0.10
- Implemented fix for shows not finding subs

v2.0.3 (2025-11-22)
- Implemented changes from v1.0.5 till v1.0.8

v2.0.2 (2024-05-22)
- Implemented changes from v1.0.3 and v1.0.4

v2.0.1 (2024-04-07)
- Add possibility to choose the Kodi selected subtitle font

v2.0.0 (2023-11-29)
- Add dual subtitle support

v1.0.10 (2026-07-01)
- fixed "ModuleNotFoundError: No module named 'resources.lib.os'" on some devices (notably Android): added package __init__.py files so imports no longer rely on implicit namespace packages, and renamed the internal 'os' package to 'osclient' to stop it shadowing Python's standard-library os module
- fixed subtitle search for TV shows in non-English (localized) libraries by querying the show's original title from the Kodi library instead of the translated on-screen title (thanks notoco)

v1.0.9 (2026-03-01)
- added Test Connection button in settings to verify credentials and view account info
- show specific error message when search or download fails (thanks wildsands)
- added search results caching with configurable duration (thanks VipSaran)
- fixed trailing slash on subdirectory folder path (thanks peno64)

v1.0.8 (2025-09-04)
- performs a query to kodi library if imdb or tmdb ID is missing (thanks you cvanderkam)

v1.0.7 (2025-08-26)
- added IMDB and TMDB collection on files for more accurate search to the API

v1.0.6 (2024-11-29)
- fixed issue with RAR archives (thanks ninjacarr)
- handles default chinese language to zh-cn  (thanks ninjacarr)

v1.0.5 (2024-07-30)
- fixed issue with portuguese file names
- added AI translated filter (thanks Kate6)

v1.0.4 (2024-01-15)
- Sanitize language query
- Improved sorting
- Improved error messages
- Improved usage of moviehash

v1.0.3 (2023-12-18)
- Fixed issue with file path

v1.0.2 (2023-08-28)
- Update user agent header

v1.0.1 (2023-07-28)
- Remove limit of 10 subtitles for the returned values
- Fix Portuguese and Brazilian flags

1.0.0
 Initial version, forked from https://github.com/juokelis/service.subtitles.opensubtitles
 Search fixed and improved

# Installation in kodi:
Via repository https://peno64.github.io/repository.peno64/